# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 19:16:51 2018

@author: hp
"""

'''l=['P','y','t','h','o','n']
print(l)
for a in l:
    print(a, end=' ')
    
l=['queen','west','east','rest','tie','yet']
length=len(l)
print(length)
for a in range(length,0,-1):
    print("At index",a, "element: ",l[a])
 
string=int(input("enter any number: "))
print(type(string))
    
thislist=['apple', 'banana', 'cherry']
print(thislist)

L1=list(input('Enter the elements:'))
print(L1) 

lst = list(input('enter the elements of the list:'))
print('list u entered is:',lst)

thislist=["apple", "banana", "cherry"]
print(thislist[1])

thislist=["apple", "banana", "cherry"]
print(id(thislist))
thislist[1]= "blackcurrant"
print(id(thislist))
print(thislist)

thislist=["apple", "banana", "cherry"]
for x in thislist:
  	print(x)

thislist = ["apple", "banana", "cherry"]
thislist.append("orange")
print(thislist)

thislist = ["apple", "banana", "cherry"]
print(id(thislist[1]))
thislist.insert(1, "orange")
print(id(thislist[2]))
print(thislist)

thislist = ["apple", "banana", "cherry"]
thislist.remove(thislist[1])
print(thislist)

thislist = ["apple", "banana", "cherry"]
thislist.pop(1)
print(thislist)

lst1=[1,2,3]
lst2=[2,3,4]
print(lst1*lst2)'''

t1=['a','b','c']
t2=['d','e']
t3=t1.extend(t2)
print(t1)

