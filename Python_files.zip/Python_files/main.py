
"""import constant

print(constant.PI)
print(constant.GRAVITY)"""

a = 45
b = 78
add = a + b
print(add)

if add > 100:
    print("Century")

