"""l = "Python"
print(list(l))
for a in l:
    print(a)

t = (234, "hello", [1, 3, 5], (34.78, "Madam"))
for a in t:
    print(a)"""

string = """ This is thefourth day
               in december"""
print(string)
string1 = " Hello" \
          " I am Jasmeet"
print(string1)