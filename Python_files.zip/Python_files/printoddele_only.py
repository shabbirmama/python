num = [7, 8, 120, 25, 44, 20, 27]
num = [x for x in num if x % 2!=0]
print("List with odd elements only: ")
print(num)
num = [7, 8, 120, 25, 44, 20, 27]
num = [x for x in num if x % 2 == 0]
print("List with even elements only: ")
print(num)