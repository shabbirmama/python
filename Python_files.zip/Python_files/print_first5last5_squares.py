lst = list()
for i in range(1, 31):
    lst.append(i**2)
print(lst)
print(lst[0:5])
print(lst[-5:])

