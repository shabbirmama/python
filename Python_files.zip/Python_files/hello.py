# -*- coding: utf-8 -*-
"""
Created on Tue Nov 13 10:13:10 2018

@author: hp
"""

#print("Hello World!")

#Addition of two numbers
#num1=12

'''num2=24
result=num1+num2
print("Addition of two numbers is", result)

avg=result/2
print(avg)
num1=3.5
print(num1)

a=4
b=2
if(a>b):
    print("a is  greater than b")

iff=4

a="Jas"
if(a==8):
    print(a)
print(a)

website="Apple.com"

website="Programmingworld.com"
print(website)

x,y,z=1,3,2
print(x,y,z)'''

x=y=z="same"
print(x)
print(y)
print(z)













