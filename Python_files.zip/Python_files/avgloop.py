# -*- coding: utf-8 -*-
"""
Created on Mon Nov 19 10:48:20 2018

@author: hp
"""

x=int(input("Enter the limit of the numbers to be averaged: "))