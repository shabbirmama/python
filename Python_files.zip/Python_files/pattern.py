# -*- coding: utf-8 -*-
"""
Created on Sat Nov 10 13:13:21 2018

@author: hp
"""

for i in range(1, 5):  # i = 1,2,3,4
    for j in range(1, i):  # j = 1,4
        print("$", end=' ')
    print()
"""
for i in range(1,7):
    for j in range(1,i):
        print("*", end=' ')
    print()
    for j in range(7,i):
        print("*", end=' ')
    print()


'''for num in range(15,25):
    for i in range(2,num):
        if(num%i==0):
             print("Found a factor", i, "for", num)
             break
    else:
        print(num, "is a prime number")
        
#incr=1
val=65
for i in range(0,6): #i=0,1
    
    for j in range(0,i+1,2):
        ch=chr(val)
        print(ch, end=' ')
        val+=1
    #incr+=2
    print()
    
dig=0
for i in range(0, 5):
    
    for j in range(0, i+1):
        print(dig, end=" ")
    dig+=2
    print()
 
  
x=int(input('Please Enter the number for Pattern: '))
for i in range(0,x): #i=0,1
    for j in range(x,i,-1): #j=5,4,3,2,1
        print(j, end=' ')
    print()
    
x=int(input('Please Enter a number : '))
y=0
for i in range(1,x,2):
            z=i**2
            y=y+z
print(y)

y = int(input('Please Enter Range : '))
z=y+1
for i in range(1, z):
    print('1'*i)"""
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
       