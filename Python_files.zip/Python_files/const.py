# -*- coding: utf-8 -*-
"""
Created on Thu Nov 22 14:37:29 2018

@author: hp
"""

PI=3.14
GRAVITY=9.8