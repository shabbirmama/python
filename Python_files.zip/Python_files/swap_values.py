
"""x = 5
y = 7

x, y = y, x

print("x = ",x, "y = ", y)"""

name = "simar"
age = 20

print("name is", name, end=" ")
print("age is ", age)
print("Finish")