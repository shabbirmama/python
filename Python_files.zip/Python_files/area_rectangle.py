# Program to take input from user the sides of a rectangle and calculate its area

length = float(input("Enter the first side of a rectangle: "))
breadth = float(input("Enter the second side of a rectangle: "))
unit = input("Enter the unit for the value of the area: ")
area = length * breadth

print("The length of rectangle is", length)
print("The breadth of rectangle is", breadth)
print("The area of a rectangle is", area, unit)
