# -*- coding: utf-8 -*-
"""
Created on Tue Nov 27 12:02:43 2018

@author: hp
"""
'''l1=eval(input("Enetr the elements for the list: "))
print(l1)

#l=eval(x)
print(x)'''

thislist=["Apple","Cherry","Banana"]
for x in thislist:
    print(x)